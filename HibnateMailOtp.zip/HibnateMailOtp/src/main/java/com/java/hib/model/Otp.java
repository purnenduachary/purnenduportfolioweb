package com.java.hib.model;

public class Otp {

}
